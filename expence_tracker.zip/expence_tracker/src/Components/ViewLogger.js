import { Grid, Paper,Typography,Select,InputLabel,FormControl, Button} from '@material-ui/core'
import React from 'react'
import {useStyleAction} from '../Style/style';

function ViewLogger() {
    return (
        <div>
            
        </div>
    )
}

export default ViewLogger
